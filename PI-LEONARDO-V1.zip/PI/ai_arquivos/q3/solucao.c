// Questao 03
// Implemente aqui uma funcao chamada ex3_solucao
void ex3_solucao(short *rdi, short *rsi, long rdx)
{
    long *rcx;
    rcx = &rdx;

    int edx = (int)*rdi;
    int eax = (int)*rsi;

    short ax = (short) eax;
    short dx = (short) edx;

    *rdi = ax; //mov    %ax,(%rdi)
    *rsi = dx; //mov    %dx,(%rsi)

    eax = (int) *rdi;

    eax = 5 * eax;
    edx = 3 * edx;

    eax += edx;
    *rcx = ax;

    //return eax;
}